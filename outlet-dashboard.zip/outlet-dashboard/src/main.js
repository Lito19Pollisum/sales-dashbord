import "./style.css";
import { createClient } from "@supabase/supabase-js";

const OUTLETS = ["All", "Tampines", "Jurong", "Orchard"];
const THRESHOLD = 90;

/* ------------------------------------------------------------------
   DATA LOADING — the only place data enters the dashboard.
   Returns a Promise of rows: {outlet, week, sales, target, orders, returns}
   Source: Supabase table public.outlet_weekly (read-only via RLS).
   Config comes from VITE_SUPABASE_URL and VITE_SUPABASE_KEY.
------------------------------------------------------------------- */
async function loadData() {
  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_KEY;
  if (!url || !key) {
    throw new Error("Missing VITE_SUPABASE_URL or VITE_SUPABASE_KEY environment variable.");
  }
  const supabase = createClient(url, key);
  const { data, error } = await supabase
    .from("outlet_weekly")
    .select("outlet, week, sales, target, orders, returns")
    .order("outlet")
    .order("week");
  if (error) throw error;
  return data.map(r => ({
    outlet: r.outlet,
    week: r.week,
    sales: Number(r.sales),
    target: Number(r.target),
    orders: Number(r.orders),
    returns: Number(r.returns)
  }));
}

/* ---------------- rendering ---------------- */
let ROWS = [];
let current = "All";

const $ = id => document.getElementById(id);
const nf = new Intl.NumberFormat("en-SG");
const money = n => "$" + nf.format(Math.round(n));
const pct = (a, b) => (b ? (a / b) * 100 : 0);
const fmtWeek = w => new Date(w + "T00:00:00").toLocaleDateString("en-SG", { day: "numeric", month: "short" });

function buildFilter() {
  $("filter").innerHTML = OUTLETS.map(o =>
    `<button data-o="${o}" class="${o === current ? "active" : ""}">${o}</button>`).join("");
  $("filter").onclick = e => {
    const b = e.target.closest("button");
    if (!b) return;
    current = b.dataset.o;
    buildFilter();
    render();
  };
}

function render() {
  const rows = current === "All" ? ROWS : ROWS.filter(r => r.outlet === current);

  // KPIs
  const sales = rows.reduce((s, r) => s + r.sales, 0);
  const target = rows.reduce((s, r) => s + r.target, 0);
  const orders = rows.reduce((s, r) => s + r.orders, 0);
  const returns = rows.reduce((s, r) => s + r.returns, 0);
  const tp = pct(sales, target);
  const rp = pct(returns, orders);
  $("kpis").innerHTML = `
    <div class="card kpi"><div class="label">Total sales</div><div class="value">${money(sales)}</div><div class="note">Target ${money(target)}</div></div>
    <div class="card kpi"><div class="label">% of target</div><div class="value ${tp < THRESHOLD ? "bad" : ""}">${tp.toFixed(1)}%</div><div class="note">${tp >= 100 ? "Above" : "Below"} target</div></div>
    <div class="card kpi"><div class="label">Orders</div><div class="value">${nf.format(orders)}</div><div class="note">${rows.length} outlet-weeks</div></div>
    <div class="card kpi"><div class="label">Returns %</div><div class="value">${rp.toFixed(2)}%</div><div class="note">${nf.format(returns)} returns</div></div>`;

  // date range
  const weeks = [...new Set(rows.map(r => r.week))].sort();
  $("range").textContent = weeks.length
    ? `${current === "All" ? "All outlets" : current} · weeks of ${fmtWeek(weeks[0])} – ${fmtWeek(weeks[weeks.length - 1])}`
    : "";

  // chart
  const MAX = 120;
  const sorted = [...rows].sort((a, b) => a.outlet.localeCompare(b.outlet) || a.week.localeCompare(b.week));
  const lines = [0, 50, 100].map(v =>
    `<div class="gridline ${v === 100 ? "tgt" : ""}" style="bottom:${v / MAX * 100}%"><span>${v}%</span></div>`).join("")
    + `<div class="gridline thr" style="bottom:${THRESHOLD / MAX * 100}%"><span>${THRESHOLD}%</span></div>`;
  const bars = sorted.map(r => {
    const p = pct(r.sales, r.target);
    return `<div class="col" title="${r.outlet}, week of ${fmtWeek(r.week)}: ${money(r.sales)} of ${money(r.target)}">
      <div class="bar ${p < THRESHOLD ? "low" : ""}" style="height:${Math.min(p, MAX) / MAX * 100}%"><b>${p.toFixed(0)}%</b></div></div>`;
  }).join("");
  $("chart").innerHTML = lines + `<div class="bars">${bars}</div>`;
  $("xlabels").innerHTML = sorted.map(r => `<div><strong>${r.outlet}</strong>${fmtWeek(r.week)}</div>`).join("");

  // needs attention
  const low = sorted.map(r => ({ ...r, p: pct(r.sales, r.target) }))
    .filter(r => r.p < THRESHOLD)
    .sort((a, b) => a.p - b.p);
  $("attn").innerHTML = low.length
    ? low.map(r => `<li><div><div class="who">${r.outlet}</div><div class="meta">Week of ${fmtWeek(r.week)} · ${money(r.target - r.sales)} short</div></div>
        <div class="pct">${r.p.toFixed(1)}%<div class="meta">${money(r.sales)} / ${money(r.target)}</div></div></li>`).join("")
    : `<li class="empty">Nothing under ${THRESHOLD}% of target.</li>`;
}

loadData()
  .then(rows => { ROWS = rows; buildFilter(); render(); })
  .catch(err => {
    document.querySelector(".wrap").insertAdjacentHTML("beforeend",
      `<p class="err">Failed to load data: ${err.message}</p>`);
  });
